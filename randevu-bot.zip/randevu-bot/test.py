print ('Hello Python VS Code!')
import time
import requests
from bs4 import BeautifulSoup

# Pushover kullanıcı anahtarını ve uygulama API anahtarını buraya yapıştır
USER_KEY = "u4jkuwn73addh4tnxx3m7rfr13nr9b"
API_KEY = "anynw75jtwwki59sdpajkteb9nf729"

# Bildirim gönderme fonksiyonu
def send_notification(title, message):
    url = "https://api.pushover.net/1/messages.json"
    data = {
        "token": API_KEY,
        "user": USER_KEY,
        "title": title,
        "message": message
    }
    response = requests.post(url, data=data)
    if response.status_code == 200:
        print("Bildirim gönderildi!")
    else:
        print(f"Bildirim gönderilemedi: {response.status_code}")

# Randevu sayfasını izleme fonksiyonu
def check_appointment():
    url = "https://basvuru.kosmosvize.com.tr/appointmentform"  # Randevu sayfasının URL'sini buraya yapıştır
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.content, "html.parser")

        # Randevu var mı kontrol et
        if "Randevu mevcut" in soup.text or "Appointment available" in soup.text:
            send_notification("Randevu Açıldı!", "Hemen kontrol et: " + url)
        else:
            print("Randevu yok, tekrar deneyeceğim...")
    except Exception as e:
        print(f"Hata: {e}")

# Sürekli izleme döngüsü
while True:
    check_appointment()
    time.sleep(60)  # 60 saniye bekle
